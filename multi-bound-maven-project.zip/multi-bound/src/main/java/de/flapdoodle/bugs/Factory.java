package de.flapdoodle.bugs;

public class Factory<T, F extends AbstractComp & HasValue<T>> {

}
