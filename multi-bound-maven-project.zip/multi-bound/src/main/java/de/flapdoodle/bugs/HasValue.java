package de.flapdoodle.bugs;

public interface HasValue<T> {
	boolean isReadOnly();
}
