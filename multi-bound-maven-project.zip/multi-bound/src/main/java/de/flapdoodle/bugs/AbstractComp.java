package de.flapdoodle.bugs;

public abstract class AbstractComp {
	protected abstract boolean isReadOnly();
}